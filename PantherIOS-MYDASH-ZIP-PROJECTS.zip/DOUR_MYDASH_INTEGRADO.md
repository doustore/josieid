# DOUR MYDASH — panel principal

La app abre directamente en MYDASH. Se retiró la pantalla de calculadora y el acceso visual al explorador de patches de la navegación inicial.

## Proyectos ZIP

En la pestaña **Proyectos** se pueden importar archivos `.zip` desde Archivos, seleccionar una key existente y pulsar **Conectar**. La asociación queda guardada localmente y se muestra en la tarjeta de la key. Al borrar un ZIP, también se elimina su asociación.

## Keys y alcance

Las keys y asociaciones se guardan en UserDefaults y los ZIP en `Documents/MyDashProjects`. Esta implementación es local al dispositivo: no valida keys en otros teléfonos, no distribuye el ZIP a usuarios remotos y no se conecta a Telegram ni a una API. Para eso hace falta un backend con autenticación y almacenamiento compartido.

Acceso inicial: `admin` / `dour2026` (cambiar desde Ajustes).
