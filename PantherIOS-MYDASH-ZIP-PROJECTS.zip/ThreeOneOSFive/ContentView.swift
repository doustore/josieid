import SwiftUI

struct ContentView: View {
    var body: some View {
        DOURMydashView()
            .preferredColorScheme(.dark)
            .statusBarHidden(false)
    }
}
