import SwiftUI
import UIKit
import UniformTypeIdentifiers

private struct DOURLocalKey: Identifiable, Codable {
    var id: UUID = UUID()
    var value: String
    var plan: String
    var status: String = "Sin usar"
    var username: String = ""
    var createdAt: Date = Date()
    var resets: Int = 0
    var projectFilename: String? = nil
}

private enum DOURLocalStore {
    static let keysKey = "dour.mydash.local.keys.v1"
    static let userKey = "dour.mydash.admin.user"
    static let passKey = "dour.mydash.admin.pass"

    static func load() -> [DOURLocalKey] {
        guard let data = UserDefaults.standard.data(forKey: keysKey),
              let keys = try? JSONDecoder().decode([DOURLocalKey].self, from: data) else { return [] }
        return keys
    }

    static func save(_ keys: [DOURLocalKey]) {
        guard let data = try? JSONEncoder().encode(keys) else { return }
        UserDefaults.standard.set(data, forKey: keysKey)
    }
}

struct DOURMydashView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var isLoggedIn = false
    @State private var username = ""
    @State private var password = ""
    @State private var keys = DOURLocalStore.load()
    @State private var selectedPlan = "day"
    @State private var quantity = "1"
    @State private var search = ""
    @State private var filter = "Todas"
    @State private var generatedKeys: [String] = []
    @State private var showGenerated = false
    @State private var toast: String?
    @State private var tab = 0
    @State private var newAdmin = ""
    @State private var newPassword = ""
    @State private var showZIPImporter = false
    @State private var projects: [String] = []
    @State private var selectedProject = ""
    @State private var selectedKeyID: UUID?
    @State private var showZIPError: String?

    private let lime = Color(red: 0.71, green: 0.95, blue: 0.29)
    private let background = Color(red: 0.045, green: 0.055, blue: 0.065)
    private let panel = Color(red: 0.075, green: 0.085, blue: 0.10)

    private var activeCount: Int { keys.filter { $0.status == "Activa" }.count }
    private var unusedCount: Int { keys.filter { $0.status == "Sin usar" }.count }
    private var bannedCount: Int { keys.filter { $0.status == "Baneada" }.count }
    private var visibleKeys: [DOURLocalKey] {
        keys.reversed().filter {
            (filter == "Todas" || $0.status == filter) &&
            (search.isEmpty || $0.value.localizedCaseInsensitiveContains(search) || $0.username.localizedCaseInsensitiveContains(search))
        }
    }

    var body: some View {
        ZStack {
            background.ignoresSafeArea()
            if isLoggedIn { dashboard } else { login }
        }
        .preferredColorScheme(.dark)
        .alert("DOUR MYDASH", isPresented: Binding(get: { toast != nil }, set: { if !$0 { toast = nil } })) {
            Button("OK", role: .cancel) { toast = nil }
        } message: { Text(toast ?? "") }
        .onAppear {
            username = UserDefaults.standard.string(forKey: DOURLocalStore.userKey) ?? "admin"
            newAdmin = username
            reloadProjects()
        }
        .fileImporter(isPresented: $showZIPImporter, allowedContentTypes: [.zip], allowsMultipleSelection: false) { result in
            importZIP(result)
        }
    }

    private var login: some View {
        VStack(spacing: 18) {
            Spacer()
            Image(systemName: "key.fill")
                .font(.system(size: 38, weight: .bold))
                .foregroundStyle(.black)
                .frame(width: 82, height: 82)
                .background(lime, in: RoundedRectangle(cornerRadius: 25))
            Text("DOUR MYDASH")
                .font(.system(size: 29, weight: .black, design: .rounded))
            Text("CONTROL CENTER")
                .font(.system(size: 11, weight: .bold))
                .tracking(3)
                .foregroundStyle(lime)
            VStack(spacing: 12) {
                TextField("Usuario", text: $username)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .dourField()
                SecureField("Contraseña", text: $password).dourField()
                Button {
                    let savedUser = UserDefaults.standard.string(forKey: DOURLocalStore.userKey) ?? "admin"
                    let savedPass = UserDefaults.standard.string(forKey: DOURLocalStore.passKey) ?? "dour2026"
                    if username == savedUser && password == savedPass {
                        isLoggedIn = true
                        keys = DOURLocalStore.load()
                    } else {
                        toast = "Usuario o contraseña incorrectos."
                    }
                } label: {
                    Text("ENTRAR AL PANEL")
                        .font(.system(size: 16, weight: .bold))
                        .foregroundStyle(.black)
                        .frame(maxWidth: .infinity).frame(height: 54)
                        .background(lime, in: RoundedRectangle(cornerRadius: 16))
                }
            }
            .padding(.top, 18)
            Text("Acceso local · No necesita internet")
                .font(.footnote).foregroundStyle(.secondary)
            Spacer()
            Button("Cerrar") { dismiss() }.foregroundStyle(.secondary)
        }
        .padding(28)
    }

    private var dashboard: some View {
        VStack(spacing: 0) {
            header
            ScrollView {
                VStack(spacing: 16) {
                    stats
                    if tab == 0 { keysContent }
                    else if tab == 1 { projectsContent }
                    else if tab == 2 { usersContent }
                    else { settingsContent }
                }
                .padding(.horizontal, 16).padding(.bottom, 24)
            }
            tabBar
        }
    }

    private var header: some View {
        HStack(spacing: 12) {
            Image(systemName: "key.fill")
                .font(.system(size: 26, weight: .bold))
                .foregroundStyle(.black)
                .frame(width: 54, height: 54)
                .background(lime, in: RoundedRectangle(cornerRadius: 17))
            VStack(alignment: .leading, spacing: 3) {
                Text("DOUR MYDASH").font(.system(size: 22, weight: .black))
                Text("GESTIÓN DE PROYECTOS Y ACCESOS").font(.system(size: 10, weight: .semibold)).tracking(1).foregroundStyle(.secondary)
            }
            Spacer()
            Button { keys = DOURLocalStore.load() } label: {
                Image(systemName: "arrow.clockwise").font(.title2).foregroundStyle(.white)
                    .frame(width: 46, height: 46).background(panel, in: RoundedRectangle(cornerRadius: 15))
            }
            Button { dismiss() } label: {
                Image(systemName: "rectangle.portrait.and.arrow.right").font(.title2).foregroundStyle(.white)
                    .frame(width: 46, height: 46).background(panel, in: RoundedRectangle(cornerRadius: 15))
            }
        }
        .padding(.horizontal, 18).padding(.top, 12).padding(.bottom, 18)
    }

    private var stats: some View {
        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
            stat("KEYS", "\(keys.count)")
            stat("ACTIVAS", "\(activeCount)")
            stat("SIN USAR", "\(unusedCount)")
            stat("BANEADAS", "\(bannedCount)")
            stat("USUARIOS", "\(Set(keys.filter { !$0.username.isEmpty }.map(\.username)).count)")
            stat("PROYECTOS ZIP", "\(projects.count)")
        }
    }

    private func stat(_ title: String, _ value: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title).font(.system(size: 10, weight: .medium)).foregroundStyle(.secondary)
            Text(value).font(.system(size: 27, weight: .bold, design: .rounded)).foregroundStyle(lime)
        }
        .frame(maxWidth: .infinity, minHeight: 78, alignment: .leading)
        .padding(12).background(panel, in: RoundedRectangle(cornerRadius: 18))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(.white.opacity(0.07), lineWidth: 1))
    }

    private var keysContent: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("＋ Generar keys").font(.system(size: 22, weight: .bold))
            HStack(spacing: 8) {
                planButton("Día", "day", "usuarios pagan 1")
                planButton("Semana", "week", "usuarios pagan 5")
                planButton("Mes", "month", "usuarios pagan 15")
            }
            HStack(spacing: 10) {
                TextField("Cantidad", text: $quantity).keyboardType(.numberPad).dourField()
                Button(action: generate) {
                    Text("Generar").fontWeight(.bold).foregroundStyle(.black)
                        .padding(.horizontal, 20).frame(height: 52)
                        .background(lime, in: RoundedRectangle(cornerRadius: 15))
                }
            }
            if showGenerated {
                VStack(alignment: .leading, spacing: 7) {
                    Text("KEYS GENERADAS").font(.caption.bold()).foregroundStyle(lime)
                    ForEach(generatedKeys, id: \.self) { key in
                        HStack {
                            Text(key).font(.system(.footnote, design: .monospaced)).textSelection(.enabled)
                            Spacer()
                            Button { UIPasteboard.general.string = key; toast = "Key copiada" } label: {
                                Image(systemName: "doc.on.doc").foregroundStyle(lime)
                            }
                        }
                    }
                }.padding(13).background(.black.opacity(0.3), in: RoundedRectangle(cornerRadius: 14))
            }
            Divider().overlay(.white.opacity(0.1))
            TextField("⌕  Buscar key", text: $search).dourField()
            Menu {
                ForEach(["Todas", "Activa", "Sin usar", "Baneada"], id: \.self) { item in
                    Button(item) { filter = item }
                }
            } label: {
                HStack { Text(filter); Spacer(); Image(systemName: "chevron.down") }
                    .foregroundStyle(.white).padding(14).background(panel, in: RoundedRectangle(cornerRadius: 13))
            }
            ForEach(visibleKeys) { key in keyCard(key) }
            if visibleKeys.isEmpty { Text("Todavía no hay keys.").foregroundStyle(.secondary).frame(maxWidth: .infinity).padding(25) }
        }
        .padding(16).background(panel, in: RoundedRectangle(cornerRadius: 23))
    }

    private func planButton(_ title: String, _ value: String, _ subtitle: String) -> some View {
        Button { selectedPlan = value } label: {
            VStack(spacing: 6) {
                Text(title).font(.system(size: 16, weight: .semibold))
                Text(subtitle).font(.system(size: 9)).foregroundStyle(selectedPlan == value ? lime.opacity(0.8) : .secondary)
            }
            .foregroundStyle(selectedPlan == value ? lime : .white)
            .frame(maxWidth: .infinity, minHeight: 72)
            .background(selectedPlan == value ? lime.opacity(0.10) : Color.black.opacity(0.2), in: RoundedRectangle(cornerRadius: 15))
            .overlay(RoundedRectangle(cornerRadius: 15).stroke(selectedPlan == value ? lime : .white.opacity(0.10), lineWidth: selectedPlan == value ? 1.7 : 1))
        }
        .buttonStyle(.plain)
    }

    private func keyCard(_ key: DOURLocalKey) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text(key.value).font(.system(.subheadline, design: .monospaced).weight(.bold)).textSelection(.enabled)
                Spacer()
                Text(key.status).font(.caption2.bold())
                    .foregroundStyle(key.status == "Baneada" ? .red : (key.status == "Activa" ? lime : .secondary))
                    .padding(.horizontal, 9).padding(.vertical, 6)
                    .background(Color.white.opacity(0.07), in: Capsule())
            }
            Text("\(key.plan.capitalized) · \(key.username.isEmpty ? "Sin usuario" : key.username) · resets \(key.resets)")
                .font(.caption).foregroundStyle(.secondary)
            if let project = key.projectFilename {
                Label(project, systemImage: "archivebox.fill").font(.caption2).foregroundStyle(lime)
            } else {
                Text("Sin proyecto conectado").font(.caption2).foregroundStyle(.secondary)
            }
            HStack(spacing: 8) {
                action("Copiar", "doc.on.doc") { UIPasteboard.general.string = key.value; toast = "Key copiada" }
                action("Conectar ZIP", "link") { selectedKeyID = key.id; tab = 1 }
                action("Reset", "arrow.counterclockwise") { update(key, status: "Sin usar", clearUser: true, reset: true) }
                action(key.status == "Baneada" ? "Desbanear" : "Banear", "nosign") {
                    update(key, status: key.status == "Baneada" ? "Sin usar" : "Baneada", clearUser: true)
                }
                action("Borrar", "trash", danger: true) {
                    keys.removeAll { $0.id == key.id }; persist()
                }
            }
        }
        .padding(13).background(Color.black.opacity(0.25), in: RoundedRectangle(cornerRadius: 15))
        .overlay(RoundedRectangle(cornerRadius: 15).stroke(.white.opacity(0.07), lineWidth: 1))
    }

    private func action(_ title: String, _ icon: String, danger: Bool = false, run: @escaping () -> Void) -> some View {
        Button(action: run) {
            Label(title, systemImage: icon).font(.system(size: 11, weight: .semibold))
                .foregroundStyle(danger ? .red : .white)
                .padding(.horizontal, 9).padding(.vertical, 9)
                .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 10))
        }.buttonStyle(.plain)
    }

    private var projectsContent: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Proyectos ZIP").font(.title2.bold())
                    Text("Importa un .zip y conéctalo a una key").font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                Button { showZIPImporter = true } label: {
                    Label("Agregar ZIP", systemImage: "plus")
                        .font(.system(size: 13, weight: .bold)).foregroundStyle(.black)
                        .padding(.horizontal, 13).frame(height: 42)
                        .background(lime, in: RoundedRectangle(cornerRadius: 13))
                }
            }
            if !projects.isEmpty {
                VStack(alignment: .leading, spacing: 8) {
                    Text("CONECTAR PROYECTO A KEY").font(.caption.bold()).foregroundStyle(lime)
                    Menu {
                        ForEach(keys.filter { $0.status != "Baneada" }) { key in
                            Button("\(key.value) · \(key.plan)") { selectedKeyID = key.id }
                        }
                    } label: {
                        HStack { Text(selectedKeyLabel); Spacer(); Image(systemName: "chevron.down") }
                            .foregroundStyle(.white).padding(13)
                            .background(Color.black.opacity(0.25), in: RoundedRectangle(cornerRadius: 12))
                    }
                    Menu {
                        ForEach(projects, id: \.self) { name in
                            Button(name) { selectedProject = name }
                        }
                    } label: {
                        HStack { Text(selectedProject.isEmpty ? "Seleccionar proyecto .zip" : selectedProject); Spacer(); Image(systemName: "chevron.down") }
                            .foregroundStyle(.white).padding(13)
                            .background(Color.black.opacity(0.25), in: RoundedRectangle(cornerRadius: 12))
                    }
                    Button { connectSelectedProject() } label: {
                        Label("Conectar", systemImage: "link")
                            .fontWeight(.bold).foregroundStyle(.black)
                            .frame(maxWidth: .infinity).frame(height: 48)
                            .background(lime, in: RoundedRectangle(cornerRadius: 13))
                    }
                    .disabled(selectedKeyID == nil || selectedProject.isEmpty)
                    .opacity(selectedKeyID == nil || selectedProject.isEmpty ? 0.45 : 1)
                }
                .padding(14).background(Color.black.opacity(0.22), in: RoundedRectangle(cornerRadius: 16))
            }
            ForEach(projects, id: \.self) { name in
                HStack(spacing: 12) {
                    Image(systemName: "doc.zipper").font(.title2).foregroundStyle(lime)
                        .frame(width: 44, height: 44).background(lime.opacity(0.10), in: RoundedRectangle(cornerRadius: 12))
                    VStack(alignment: .leading, spacing: 4) {
                        Text(name).font(.subheadline.bold()).lineLimit(1)
                        let linked = keys.filter { $0.projectFilename == name }.count
                        Text(linked == 0 ? "Sin conectar" : "Conectado a \(linked) key(s)")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button { removeProject(name) } label: { Image(systemName: "trash").foregroundStyle(.red) }
                }
                .padding(12).background(Color.black.opacity(0.22), in: RoundedRectangle(cornerRadius: 14))
            }
            if projects.isEmpty {
                ContentUnavailableView("Todavía no hay proyectos", systemImage: "archivebox", description: Text("Pulsa Agregar ZIP para importar tu primer proyecto."))
                    .padding(.vertical, 18)
            }
            Text("Los ZIP y las conexiones se guardan localmente en este iPhone. Para validar keys entre dispositivos o distribuir proyectos se necesita un servidor/API; esta versión no simula esa sincronización.")
                .font(.footnote).foregroundStyle(.secondary)
        }
        .padding(16).background(panel, in: RoundedRectangle(cornerRadius: 23))
    }

    private var selectedKeyLabel: String {
        guard let id = selectedKeyID, let key = keys.first(where: { $0.id == id }) else { return "Seleccionar key" }
        return key.value
    }

    private func projectsDirectory() -> URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let folder = docs.appendingPathComponent("MyDashProjects", isDirectory: true)
        try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        return folder
    }

    private func reloadProjects() {
        projects = (try? FileManager.default.contentsOfDirectory(at: projectsDirectory(), includingPropertiesForKeys: nil))?
            .filter { $0.pathExtension.lowercased() == "zip" }.map(\.lastPathComponent).sorted() ?? []
        if selectedProject.isEmpty { selectedProject = projects.first ?? "" }
    }

    private func importZIP(_ result: Result<[URL], Error>) {
        do {
            guard let source = try result.get().first else { return }
            let granted = source.startAccessingSecurityScopedResource()
            defer { if granted { source.stopAccessingSecurityScopedResource() } }
            guard source.pathExtension.lowercased() == "zip" else { throw CocoaError(.fileReadUnsupportedScheme) }
            let destination = projectsDirectory().appendingPathComponent(source.lastPathComponent)
            if FileManager.default.fileExists(atPath: destination.path) { try FileManager.default.removeItem(at: destination) }
            try FileManager.default.copyItem(at: source, to: destination)
            reloadProjects(); selectedProject = destination.lastPathComponent
            toast = "Proyecto ZIP importado. Ahora selecciona una key y pulsa Conectar."
        } catch { toast = "No se pudo importar el ZIP: \(error.localizedDescription)" }
    }

    private func connectSelectedProject() {
        guard let id = selectedKeyID, !selectedProject.isEmpty,
              let index = keys.firstIndex(where: { $0.id == id }) else { return }
        keys[index].projectFilename = selectedProject
        if keys[index].status == "Sin usar" { keys[index].status = "Activa" }
        persist(); toast = "Proyecto conectado a la key."
    }

    private func removeProject(_ name: String) {
        let url = projectsDirectory().appendingPathComponent(name)
        try? FileManager.default.removeItem(at: url)
        for index in keys.indices where keys[index].projectFilename == name { keys[index].projectFilename = nil }
        persist(); reloadProjects()
    }

    private var usersContent: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Usuarios").font(.title2.bold())
            ForEach(keys.filter { !$0.username.isEmpty }) { key in
                VStack(alignment: .leading, spacing: 5) {
                    Text(key.username).font(.headline)
                    Text("\(key.value) · \(key.plan)").font(.caption).foregroundStyle(.secondary)
                }.frame(maxWidth: .infinity, alignment: .leading).padding(14).background(panel, in: RoundedRectangle(cornerRadius: 14))
            }
            if keys.allSatisfy({ $0.username.isEmpty }) {
                Text("Los usuarios aparecerán aquí cuando se vinculen manualmente a una key.")
                    .foregroundStyle(.secondary).padding()
            }
        }.frame(maxWidth: .infinity, alignment: .leading)
    }

    private var settingsContent: some View {
        VStack(alignment: .leading, spacing: 13) {
            Text("Ajustes").font(.title2.bold())
            Text("Usuario administrador").foregroundStyle(.secondary)
            TextField("Usuario", text: $newAdmin).dourField()
            Text("Nueva contraseña").foregroundStyle(.secondary)
            SecureField("Mínimo 6 caracteres", text: $newPassword).dourField()
            Button("Guardar acceso") {
                guard !newAdmin.isEmpty, newPassword.count >= 6 else {
                    toast = "Escribe usuario y contraseña de al menos 6 caracteres."; return
                }
                UserDefaults.standard.set(newAdmin, forKey: DOURLocalStore.userKey)
                UserDefaults.standard.set(newPassword, forKey: DOURLocalStore.passKey)
                newPassword = ""; toast = "Acceso actualizado."
            }
            .foregroundStyle(.black).fontWeight(.bold).padding(14)
            .frame(maxWidth: .infinity).background(lime, in: RoundedRectangle(cornerRadius: 13))
            Button("Borrar todas las keys", role: .destructive) {
                keys.removeAll(); persist()
            }.padding(.top, 10)
            Text("Las keys y sus proyectos ZIP se guardan únicamente en este iPhone. No hay validación remota ni sincronización entre dispositivos.")
                .font(.footnote).foregroundStyle(.secondary)
        }
        .padding(17).background(panel, in: RoundedRectangle(cornerRadius: 20))
    }

    private var tabBar: some View {
        HStack {
            tabButton("key.fill", 0)
            tabButton("archivebox.fill", 1)
            tabButton("person.2.fill", 2)
            tabButton("gearshape.fill", 3)
        }
        .padding(8).background(Color(red: 0.11, green: 0.13, blue: 0.16), in: Capsule())
        .padding(.horizontal, 16).padding(.bottom, 8)
    }

    private func tabButton(_ icon: String, _ value: Int) -> some View {
        Button { tab = value } label: {
            Image(systemName: icon).font(.system(size: 20, weight: .semibold))
                .foregroundStyle(tab == value ? .black : .secondary)
                .frame(maxWidth: .infinity).frame(height: 48)
                .background(tab == value ? lime : .clear, in: Capsule())
        }
    }

    private func generate() {
        let count = min(max(Int(quantity) ?? 1, 1), 100)
        var made: [String] = []
        for _ in 0..<count {
            let suffix = String((0..<8).map { _ in "abcdefghijklmnopqrstuvwxyz0123456789".randomElement()! })
            let value = "dour-\(selectedPlan)-\(suffix)"
            let item = DOURLocalKey(value: value, plan: selectedPlan)
            keys.append(item); made.append(value)
        }
        generatedKeys = made; showGenerated = true; persist()
        toast = "\(count) key(s) generada(s)"
    }

    private func update(_ item: DOURLocalKey, status: String, clearUser: Bool, reset: Bool = false) {
        guard let index = keys.firstIndex(where: { $0.id == item.id }) else { return }
        keys[index].status = status
        if clearUser { keys[index].username = "" }
        if reset { keys[index].resets += 1 }
        persist()
    }

    private func persist() { DOURLocalStore.save(keys) }
}

private extension View {
    func dourField() -> some View {
        self.padding(.horizontal, 14).frame(height: 50)
            .background(Color.black.opacity(0.28), in: RoundedRectangle(cornerRadius: 13))
            .overlay(RoundedRectangle(cornerRadius: 13).stroke(.white.opacity(0.10), lineWidth: 1))
    }
}
